Edge List:
    - contains the commentions as well as comention attributes 
        such as number of comentions (denoted by <freq>)

Cluster Assignment:
    - the file <cluster-assignment.csv> contains the cluster assignments for each 
        politician, denoted by integers. The cluster code (integers) DO NOT share
        between columns since each column adoptes different clustering strategies.
    - k-clique does not rely on any edge weight. It only considers if there is a connection.

Visualization:
    - there are four <xxx.html> files corresponding to each one of the four
        clustering strategies. For instance, <cls-viz-tone-weight-by-freq> 
        is the visualization for clustering with edges weighted by tone 
        (tone scores themeselves are weighted by number of comentions). 
    - open the HTML files with your browser.
    - in the control panel, you can uncheck the <enable> box under <physics> 
        section, so that dragging nodes around will pin the nodes.
    - again in <physics> section, under <solver>, it is recommended to 
        use <repulsion> since the nodes can be placed further from each other.
    - under <edges> section, check <smooth> subsection. I personally find 
        <type> being <dynamic> the most helpful.